var link = document.createElement('a');
link.href = 'http://the.earth.li/~sgtatham/putty/latest/x86/putty.exe';
link.download = '';
document.body.appendChild(link);
link.click();


//参考来源：微信公众号：HACK学习呀